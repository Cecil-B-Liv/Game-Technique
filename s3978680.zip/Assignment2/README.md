s3978680
Huynh Ngoc Tai 

Submission for Assignment 2 of Game Technique

Instruction:
For each problem, check the folder and run the main.py code, also require pygame and python 